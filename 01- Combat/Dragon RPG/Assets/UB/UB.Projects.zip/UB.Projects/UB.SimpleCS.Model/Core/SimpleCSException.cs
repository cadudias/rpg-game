﻿

namespace UB.SimpleCS.Model.Core
{
    public class SimpleCSException : System.Exception
    {
        public SimpleCSException(string message) : base(message)
        {

        }
    }
}
