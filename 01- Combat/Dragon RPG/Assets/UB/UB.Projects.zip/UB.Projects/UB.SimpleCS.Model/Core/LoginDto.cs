﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace UB.SimpleCS.Model.Core
{
    /// <summary>
    /// A sample class to hold my user login info
    /// </summary>
    public class LoginDto : BaseDto
    {
        public static string UsernamePropertyName = "Username";
        private string _username;
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public String Username
        {
            get { return _username; }
            set
            {
                _username = value;
                OnPropertyChanged(UsernamePropertyName);
            }
        }

        public static string PasswordPropertyName = "Password";
        private string _password;
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public String Password
        {
            get { return _password; }
            set
            {
                _password = value;
                OnPropertyChanged(PasswordPropertyName);
            }
        }

        public static string IsAutoLoginPropertyName = "IsAutoLogin";
        private bool _isAutoLogin;
        public bool IsAutoLogin
        {
            get { return _isAutoLogin; }
            set
            {
                _isAutoLogin = value;
                OnPropertyChanged(IsAutoLoginPropertyName);
            }
        }
    }
}
