﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UB.SimpleCS.Model.Core
{
    /// <summary>
    /// Just a helper empty class to use for no input related requests or no data responses
    /// </summary>
    public class EmptyDto : BaseDto
    {
    }
}
