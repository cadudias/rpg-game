﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using UB.SimpleCS.Model.Core;

namespace UB.SimpleCS.Model
{
    /// <summary>
    /// A custom class just to test if apiis working :)
    /// </summary>
    public class WhoAreYouDto : BaseDto
    {
        public static string NamePropertyName = "Name";
        private string _name;
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                OnPropertyChanged(NamePropertyName);
            }
        }
        
    }
}
