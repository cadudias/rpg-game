﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using Newtonsoft.Json;
using UB.SimpleCS.Api.Rest.Helpers;
using UB.SimpleCS.Model;
using UB.SimpleCS.Model.Core;

namespace UB.SimpleCS.Api.Rest.Filters
{
    /// <summary>
    /// Authenticate api callers. So unauthenticate users can not call certain api methods
    /// </summary>
    public class AuthenticateUserFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            //get parameter
            var parameter = JsonConvert.SerializeObject(actionContext.ActionArguments["request"]);

            //convert it to our Dto's
            var request = JsonConvert.DeserializeObject<Request<EmptyDto>>(parameter); //it is not important what to cast, we need only token from the request here

            //if request is not well formatted or token not sended (not exists in our loginned user list)
            if (request == null || request.Token == null || !TokenAuth.Instance.Exists(request.Token))
            {
                throw new SimpleCSException("You need to login first to call this method!");
            }
        }
    }
}