﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;
using Newtonsoft.Json;
using UB.SimpleCS.Model.Core;

namespace UB.SimpleCS.Api.Rest.Filters
{
    /// <summary>
    /// Catches the server exception and if it is an inline exception (like user not found etc.) return's a Dto for that,
    /// so client can process that error.
    /// </summary>
    public class CustomExceptionFilter : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            base.OnException(actionExecutedContext);

            if (!(actionExecutedContext.Exception is SimpleCSException)) //log only system exceptions
            {
                //log error here if you want
            }
            
            if (actionExecutedContext.Response == null)
            {
                if (actionExecutedContext.Exception is SimpleCSException)
                {
                    var resp = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new StringContent(JsonConvert.SerializeObject(new Response<EmptyDto>
                        {
                            HasError = true,
                            Error = actionExecutedContext.Exception.Message,
                        })),
                        ReasonPhrase = "Failed to process request"
                    };
                    actionExecutedContext.Response = resp;
                }
                else
                {
                    var resp = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                    {
                        Content = new StringContent(JsonConvert.SerializeObject(new Response<EmptyDto>
                        {
                            HasError = true,
                            Error = "Failed to process request (error logged to the system).",
                        })),
                        ReasonPhrase = "Failed to process request"
                    };
                    actionExecutedContext.Response = resp;
                }
            }

        }
    }
}