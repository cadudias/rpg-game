﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UB.SimpleCS.Api.Rest.Model;
using UB.SimpleCS.Model;
using UB.SimpleCS.Model.Core;

namespace UB.SimpleCS.Api.Rest.Helpers
{
    public class TokenAuth
    {
        private static readonly Lazy<TokenAuth> Manager = new Lazy<TokenAuth>(() => new TokenAuth());

        public static TokenAuth Instance => Manager.Value;

        readonly ConcurrentDictionary<string, Token> _tokens = new ConcurrentDictionary<string, Token>();

        public void Remove(Token token)
        {
            if (token == null)
            {
                return;
            }

            Token found;
            _tokens.TryRemove(token.Key, out found);
        }

        public void Add(Token token)
        {
            if (token == null)
            {
                return;
            }

            Remove(token);
            _tokens.TryAdd(token.Key, token);
        }

        public bool Exists(TokenDto tokenDto)
        {
            if (tokenDto == null)
            {
                return false;
            }

            Token found;
            _tokens.TryGetValue(tokenDto.Key, out found);

            if (found == null ||
                found.ExpiryDate < DateTime.Now)
            {
                Remove(found); //may be expired, remove from list
                return false;
            }

            return true;
        }

        public Token Get(TokenDto tokenDto)
        {
            if (tokenDto == null)
            {
                return null;
            }

            Token found;
            _tokens.TryGetValue(tokenDto.Key, out found);
            return found;
        }
    }
}