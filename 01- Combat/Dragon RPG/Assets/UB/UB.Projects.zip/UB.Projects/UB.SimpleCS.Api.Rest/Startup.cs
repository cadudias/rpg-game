﻿using Microsoft.Owin;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Owin;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http.Formatting;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

[assembly: OwinStartup(typeof(UB.SimpleCS.Api.Rest.Startup))]

namespace UB.SimpleCS.Api.Rest
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder appBuilder)
        {
            HttpConfiguration httpConfiguration = new HttpConfiguration();
            WebApiConfig.RegisterServices(httpConfiguration);
            appBuilder.UseWebApi(httpConfiguration);
            WebApiConfig.RegisterFilters(httpConfiguration);

            WebApiConfig.RegisterFormatters(httpConfiguration);

            IgnoreSSLException();
        }

        private void IgnoreSSLException()
        {   //!! trust to custom certificates, remove this if you have a valid certificate
            System.Net.ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) =>
            {
                return true;
            };
        }
    }

    public class WebApiConfig
    {
        public static void RegisterFilters(HttpConfiguration config)
        {
            var cors = new EnableCorsAttribute(ConfigurationManager.AppSettings["corsdomains"], "*", "*")
            {
                SupportsCredentials = true,
                PreflightMaxAge = 10000
            };
            config.EnableCors(cors);

            config.MapHttpAttributeRoutes();

        }
        public static void RegisterFormatters(HttpConfiguration config)
        {
            config.Formatters.Clear();

            var formatter = new JsonMediaTypeFormatter
            {
                SerializerSettings =
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                    DateFormatHandling = DateFormatHandling.IsoDateFormat,
                    DateParseHandling = DateParseHandling.DateTime,
                    DateTimeZoneHandling = DateTimeZoneHandling.Utc,
                }
            };

            config.Formatters.Add(formatter);
        }
        public static void RegisterServices(HttpConfiguration config)
        {
            //if you have services
        }
    }
}