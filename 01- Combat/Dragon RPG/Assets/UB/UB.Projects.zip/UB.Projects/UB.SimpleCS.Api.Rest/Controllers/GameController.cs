﻿
using System.Collections.Generic;
using System.Web.Http;
using UB.SimpleCS.Api.Rest.Filters;
using UB.SimpleCS.Api.Rest.Helpers;
using UB.SimpleCS.Model;
using UB.SimpleCS.Model.Core;

namespace UB.SimpleCS.Api.Rest.Controllers
{
    [RoutePrefix("game")]
    [CustomExceptionFilter]
    public class GameController : BaseController
    {
        /// <summary>
        /// Returns top scores for this game. We did not use <see cref="AuthenticateUserFilter"/> here, because it is open
        /// to every one! And using GET method because i do not need to post anything.
        /// </summary>
        /// <returns></returns>
        [Route("top-scores")]
        [HttpGet]
        public IHttpActionResult TopScores()
        {
            return Json(new Response<PageDto<ScoreDto>>
            {
                Entity = new PageDto<ScoreDto>
                {
                    Collection = new List<ScoreDto>
                    {
                        new ScoreDto {User = "mark zuck." , Point = 200},
                        new ScoreDto {User = "steven spiel." , Point = 150},
                        new ScoreDto {User = "bill gate." , Point = 140},
                        new ScoreDto {User = "tim coo." , Point = 110},
                        new ScoreDto {User = "david finch." , Point = 105}
                    }
                } //unique unpredictable key, i'm just using a guid, you have to write more secure key generation of course
            });
        }

        /// <summary>
        /// Returns only user's scores.As you can see we are using <see cref="AuthenticateUserFilter"/> here,because
        /// we want this method must be called after a certain login (user information)
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Route("scores")]
        [HttpPost]
        [AuthenticateUserFilter] //we have to use this filter if we want authentication
        public IHttpActionResult Scores(Request<PageDto<EmptyDto>> request)
        {
            //so this method has passed the token validation, we can get user info here
            var userToken = TokenAuth.Instance.Get(request.Token);
            //we can use user's token information to get his/her scores from database etc.
            var userId = userToken.UserId; //!!this is our users id, so we can make database calls with thatand get
            //only this user's scores :)

            //so if you look to the request, it contains page data; that means user wants data for specific page and size
            //you have to write a databse function to get that information in page manner
            int currentPage = request.Entity.CurrentPage;
            int pageSize = request.Entity.PageSize;
            
            //so you have to make a linq call like this:
            
            //var list = (from a in YourTableName
            //            where a.UserId == userId
            //            select a).OrderByDescending(t => t.Point) //order by points of the user or something else
            //    .Skip((currentPage - 1) * pageSize).Take(pageSize); //paging

            //and you have to convert that data to your Dto (data transfer object),
            
            //i will simulate here for page 1 and 2 :)
            if (currentPage == 1)
            {
                return Json(new Response<PageDto<ScoreDto>>
                {
                    Entity = new PageDto<ScoreDto>
                    {
                        Collection = new List<ScoreDto>
                        {
                            new ScoreDto {User = "john wo.", Point = 65},
                            new ScoreDto {User = "john wo.", Point = 60},
                            new ScoreDto {User = "john wo.", Point = 40},
                            new ScoreDto {User = "john wo.", Point = 30},
                            new ScoreDto {User = "john wo.", Point = 25}
                        }
                    }
                });
            }
            else if (currentPage == 2)
            {
                return Json(new Response<PageDto<ScoreDto>>
                {
                    Entity = new PageDto<ScoreDto>
                    {
                        Collection = new List<ScoreDto>
                        {
                            new ScoreDto {User = "john wo.", Point = 20},
                            new ScoreDto {User = "john wo.", Point = 20},
                            new ScoreDto {User = "john wo.", Point = 15},
                            new ScoreDto {User = "john wo.", Point = 10},
                            new ScoreDto {User = "john wo.", Point = 5}
                        }
                    }
                });
            }
            else
            {
                return null;
            }
        }
    }
}