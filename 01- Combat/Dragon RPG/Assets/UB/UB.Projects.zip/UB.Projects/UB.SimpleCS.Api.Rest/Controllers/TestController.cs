﻿using System.Web.Http;
using UB.SimpleCS.Api.Rest.Filters;
using UB.SimpleCS.Model;
using UB.SimpleCS.Model.Core;

namespace UB.SimpleCS.Api.Rest.Controllers
{
    [RoutePrefix("test")]
    [CustomExceptionFilter]
    public class TestController : BaseController
    {
        [Route("who-are-you")]
        [HttpGet]
        public IHttpActionResult TestMe()
        {
            var result = new WhoAreYouDto { Name = "I'm the simple client server api." };

            return Json(new Response<WhoAreYouDto>
            {
                Entity = result
            });
        }
    }
}