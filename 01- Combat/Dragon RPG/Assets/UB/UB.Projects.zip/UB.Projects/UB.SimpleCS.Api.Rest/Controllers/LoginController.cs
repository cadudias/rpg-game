﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using UB.SimpleCS.Api.Rest.Filters;
using UB.SimpleCS.Api.Rest.Helpers;
using UB.SimpleCS.Api.Rest.Model;
using UB.SimpleCS.Model;
using UB.SimpleCS.Model.Core;

namespace UB.SimpleCS.Api.Rest.Controllers
{
    [RoutePrefix("login")]
    [CustomExceptionFilter]
    public class LoginController : BaseController
    {
        [Route("authenticate")]
        [HttpPost]
        public IHttpActionResult Login(Request<LoginDto> request)
        {
            //check from database etc.:)
            if (request.Entity.Username == "john" && request.Entity.Password == "123*")
            {
                //so login info is true. Let's create a token and save it to our auth helper
                var token = new Token
                {
                    UserId = 153, //let's say his/her id is 153 on database
                    Key = Token.CreateKey(), //create a unique key
                    ExpiryDate = DateTime.Now.AddDays(7) //expire 7 days later
                };
                TokenAuth.Instance.Add(token); //add to list this new user

                return Json(new Response<TokenDto>
                {
                    Entity = new TokenDto { Key = token.Key } //return unique unpredictable key to user,so he/she will use that key to call other methods
                });
            }

            throw new SimpleCSException("Wrong user name or password!");
        }
    }
}