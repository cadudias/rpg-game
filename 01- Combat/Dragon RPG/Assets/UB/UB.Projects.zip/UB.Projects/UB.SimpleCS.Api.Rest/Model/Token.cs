﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UB.SimpleCS.Api.Rest.Model
{
    /// <summary>
    /// A helper to hold authenticated user, so no need to goto database to get that user. And of course used
    /// for certain methods to check if that user is authenticated
    /// </summary>
    public sealed class Token
    {
        /// <summary>
        /// Unique and unpredictable key for every user
        /// </summary>
        public string Key { get; set; }
        /// <summary>
        /// UserId (it may be a guid or something else according to your database structure, our example is on Int32)
        /// </summary>
        public Int32 UserId { get; set; }
        /// <summary>
        /// Expiry date if you want to remove token (and force to user login again) after a period of time
        /// </summary>
        public DateTime ExpiryDate { get; set; }

        /// <summary>
        /// Just a helper to create a unique and unpredictable key for every user, you can implement your own method if you need
        /// </summary>
        /// <returns></returns>
        public static string CreateKey()
        {
            return (Guid.NewGuid().ToString() + Guid.NewGuid() + Guid.NewGuid()).Replace("-", "");
        }
    }
}